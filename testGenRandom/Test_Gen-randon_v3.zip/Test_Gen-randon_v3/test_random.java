package main;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.smartcardio.Card;
import javax.smartcardio.CardChannel;
import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;
import javax.smartcardio.CommandAPDU;
import javax.smartcardio.ResponseAPDU;
import javax.smartcardio.TerminalFactory;

public class test_random {
	/* Constantes */
	public static final byte CLA_MONAPPLET = (byte) 0xB0;

	public static final byte INS_NOUVEL_ALEA = 0x00;

	public static byte[] APPLET_AID= { (byte)0x01, (byte)0x02, (byte)0x03, (byte)0x04, (byte)0x05, (byte)0x06, (byte)0x07, (byte)0x08, (byte)0x09, (byte)0x00, (byte)0x00 };

	public static void main(String[] args) throws IOException {
	        ResponseAPDU r;

		/* Connexion au lecteur */
		TerminalFactory factory = TerminalFactory.getDefault();
		List<CardTerminal> terminals;
		try {
			terminals = factory.terminals().list();

			System.out.println("Terminaux : "+terminals);

			CardTerminal terminal = terminals.get(0);

			/* Connexion à la carte */
			Card card = terminal.connect("T=1");
			System.out.println("Carte : "+card);

			CardChannel channel = card.getBasicChannel();

			/* Sélection de l'applet */
			r = channel.transmit(new CommandAPDU((byte)0x00, (byte)0xA4, (byte)0x04, (byte)0x00, APPLET_AID));
			if (r.getSW() != 0x9000) {
				System.out.println("Erreur lors de la sélection de l'applet");
				System.exit(1);
			}

			/* Menu principal */
			BufferedWriter out =  new BufferedWriter (new FileWriter ("/home/administrateur/test.txt", true)) ;
			for(int i=0;i<5000;i++){
			r = channel.transmit(new CommandAPDU((byte)0xB0, INS_NOUVEL_ALEA, (byte)0x01, (byte)0x00, (byte)0x00));
			if (r.getSW() != 0x9000) {
				System.out.println("Erreur : status word different de 0x9000");
			} else {
				//System.out.println(r.getData()[0]);
				//out.write(String.valueOf(r.getData()[0])+"\n");	
			    int temp = Integer.parseInt(String.valueOf(r.getData()[0]));
			    temp = Math.abs(temp);
			    out.write(Integer.toBinaryString(temp)+"\n");
			}
				
			}
				out.close();	
			/* Mise hors tension de la carte */
			card.disconnect(false);

		} catch (CardException e) {
			e.printStackTrace();
		} 
	}
}

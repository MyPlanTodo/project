%% Test sur gen_randan

x=xlsread('donnees.xls');
n=length(x);
figure(1)
plot(sort(x),(1:n)/n);
hold on
stem(sort(x),ones(n,1)*1/n,'b');
plot(x,x,'-r');
 legend('fonction de r��partition empirique','R��partition des valeurs','fonction de r��partition');
hold off
%%
nbin=900;
d=linspace(min(x),max(x),nbin+1)
for i=1:nbin
H(i)=length(find(x>d(i)&x<d(i+1)));
end
figure(2)
bar(H)
%hold on
%plot(cumsum(H),'or')
%hold off

%%
figure(2)
hist(x,50)
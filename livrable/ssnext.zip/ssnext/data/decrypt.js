/**
 * @author Maxence Pechoux, Florian Guilbert, Zakaria Addi
 * 
 * The following tags will be used to check if a message has been encrypted,
 * either anonymously or non-anonymously
 */

var anonymBalise = "SSNEncryptedA";
var nonAnonymBalise = "SSNEncryptedN";

/**
 * Once a post and its associated comments are decrypted,  
 * we modify our facebook page accordingly
 */ 

self.port.on("decrypted", function(data) {
    //We update our post
    $("#" + data["id"]).find('span.userContent').text(data['message']);
    var i = 0;
    //for each encrypted comments, we replace it by its decrypted version
    $("#" + data["id"]).find('.UFICommentContent').each(function(){
        $(this).find('.UFICommentBody:first-child').text(data['comms'][i]);
        i++;
    });
    //Once the decryption process is done, we remove the decrypt button
    $("#" + data["id"]).find('._42ft._42fu._11b.selected._42g-.decrypt').remove();
})

/**
 * Once we receive the encrypted comment we update the text input area,
 * the user will then just have press the enter key
 */
self.port.on("comEncrypted",function(data){
    $('#' + data['id']).find('textarea').val(data['encryptedCom']);
    $('#' + data['id']).find('textarea').focus();
})

/**
 * The function will add get/set keys buttons
 */
function keysButtons() {
    $('<table><tr><td><button id=\'insert\' class=\'_42ft _42fu _11b selected' 
        + ' _42g-\'>Publier ma clef</button></td></tr><tr><td><button '
        + 'id=\'getKeys\' class=\'_42ft _42fu _11b selected _42g-\'>Synchroniser'
        + ' les clefs</button></td></tr></table>')
        .insertAfter('#pagelet_welcome_box');
    $('#insert').click(function() {
        self.port.emit("insertKey");
    });
    $('#getKeys').click(function() {
        self.port.emit("getKeys");
    });
}

/**
 * Processes the encrypted post present on the facebook page
 */
function addDecryptButton() {
    console.log("adddecrypt");
    //we check each status post
    $('.storyContent:not(.processed)').addClass('processed').each(function () {
        //we retrieve the post content
        var post = $(this).find('span.userContent').text();
        //and its id
        var id_post = $(this).parent().attr("id");
        //We check if the post has an anonymous tag
        if ((post != null) && 
            (post.substr(0, anonymBalise.length) === anonymBalise)) {
            console.log("trouvé anonyme");
            //We then add add a decrypt button
            $(this).append("<button class=\'_42ft _42fu _11b selected _42g- "
                + "decrypt\' type=\'button\'>Déchiffrer</button>");
            //We specify our decrypt button behavior
            $(this).find('._42ft._42fu._11b.selected._42g-.decrypt')
                .click({value : id_post}, function(event) {
                //this function initiate the decryption process
                decryptPost(event.data.value, true);
                // We allow users to encrypt comment once the post and
                // its associated comments have been decrypted
                addComCipherButton(id_post);
            });
        //Or we check if the post has a non-anonymous tag
        } else if ((post != null) 
            && (post.substr(0, nonAnonymBalise.length) === nonAnonymBalise)) {
            console.log("trouvé non anonyme");
            // here we decrypt the post, its comment and add 
            // the cipher button directly
            decryptPost(id_post, false);
            addComCipherButton(id_post);
        }
    });
}

/**
 * We add here a button to encrypt a comment
 */
function addComCipherButton(id_post){
    // We append 
    $('#' + id_post).find('.UFIRow.UFIAddComment')
        .append('<button class=\'_42ft _42fu _11b selected _42g- decrypt\' '
        + 'id=cryptocom_'+ id_post + ' type=\'button\'>Chiffrer</button>');
    // We specify the encrypt button behavior
    $('#cryptocom_' + id_post).click({value : id_post},function(event){
        //We retrieve the text entered by the user
        var text = $('#' + event.data.value).find('textarea').val();
        // We build the JSON object with the target text, 
        // the id of the current post and the name of our action
        var mess = { action : "encryptCom", id : event.data.value, message : text}
        // And we emit it
        self.port.emit('comEncrypt', mess);
    });
}

/**
 * This function will handle the decryption process
 */
function decryptPost(id_post, anonym) {
    // We initialize the JSON object
    var req = { action : 'decrypt', ano : anonym, id : id_post, comms : [], message: ""};
    // We retrieve the post content
    var post = $('#' + id_post).find('span.userContent').text();
    console.log("post : " + post);
     // We iterate over the comment list and add each one of them to the JSON object
    $('#' + id_post).find('.UFIComment').each(function() {
        console.log($(this).find('.UFICommentBody:first-child').text());
        req['comms'].push($(this).find('.UFICommentBody:first-child').text());
    });
    // We remove the tag from the post content
    let message = post.substr(anonymBalise.length, post.length - anonymBalise.length);
    console.log("id : " + id_post);
    req['message'] = message;
    console.log("req :" + req['comms']);
    // We emit the JSON object
    self.port.emit("toDecrypt", JSON.stringify(req));
}

/**
 * When the page loaded, we check if there is any status post and proceed 
 * to call the needed function
 */
if ($('.storyContent').html() != null) {
    addDecryptButton();
    keysButtons();
    setInterval(addDecryptButton, 5000);
}
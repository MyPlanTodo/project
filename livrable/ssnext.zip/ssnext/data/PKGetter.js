/**
 * @author Maxence Pechoux
 * 
 * This function gets the value of the "About me" section, if it is not null
 * then we emit it to the addon
 */
function PKGetter() {
    var friendsKey = $('#pagelet_bio .profileText').text();
    if (friendsKey != null) {
        self.port.emit("PKReceived", friendsKey);
    }
}

PKGetter();
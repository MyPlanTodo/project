/**
 * @author: Florian Guilbert
 */ 

/**
 * This function creates a popup that will appear when the user has to type his
 * ID for his first connection with the extension.
 */
function launchPopup() {
    var div = "<div id=\"popupID\" class=\"_10 uiLayer popup_block\" "
        + "role=\"dialog\" style=\"\"><div class=\"_1yu\"><div class=\"_t\">"
        + "<form action=# class=\"_s\"><div id=\"u_a_0\" class=\"pvs phm _1yw\">"
        + "Identifiants</div><div style=\"padding:5px\" class=\"_13\"><h3>Login "
        + ":</h3><input type=\"text\" id=\"loginInput\" placeholder=\"votre "
        + "login\" /><h3>Mot de passe : </h3><input type=\"password\" "
        + "placeholder=\"votre mot de passe\" id=\"passwordInput\" /><br />"
        + "*Il vous est conseillé de changer votre mot de passe une fois "
        + "identifié<br /> (il sera généré automatiquement à l'aide de votre "
        + "carte). <br /></div><div class=\"_14\" ><div class=\"pam "
        + "uiOverlayFooter uiBoxGray topborder\" ><table class=\"uiGrid\" "
        + "cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"prs "
        + "uiOverlayFooterMessage\"><td class=\"uiOverlayFooterButtons\">"
        + "<label class=\"layerConfirm uiOverlayButton uiButton uiButtonConfirm"
        + "uiButtonLarge\" for=\"validButton\"><input id=\"validButton\" "
        + "type=\"submit\" value=\"Valider\"/></label></td></tr></table></div>"
        + "</div></div></div></div>";
    $("body").append(div);1
    $('.popup_block').css({
        'display': 'none',
        'float': 'left', 
        'z-index': '999999'
    });
    
    /**
     * When the user clicks on the popup's valid button, his ID are sent to
     * FaceCrypt.
     */
    $("#validButton").click(function() {
        var id = $("#loginInput").val();
        var passwd = $("#passwordInput").val();
        $('#fade , .popup_block').fadeOut(function() {
        });
        var obj = {action : "setID", login : id, pass : passwd};
        self.port.emit("setID", obj);
        console.log(id + " " + passwd + " " + res); 
        return false;
    });
    var popID = $("#popupID").attr("id")
    var popWidth = 300;

	$('#' + popID).fadeIn().css({ 'width': popWidth});

	var popMargTop = ($('#' + popID).height() + 80) / 2;
	var popMargLeft = ($('#' + popID).width() + 80) / 2;
	
    $('#' + popID).css({ 
        'margin': 'auto',
		'margin-top' : '40px'
    });
	
	$('body').append('<div id="fade"></div>');
	$('#fade').css(
        {'filter' : 'alpha(opacity=60)',
        'display' : 'none',
        'background' : '#000',
        'position' : 'fixed',
        'left' : '0',
        'top' : '0',
        'width' : '100%',
        'height' : '100%',
        'opacity': '.80',
        'z-index': '9999'}).fadeIn();

    $('body').on('click', 'a.close, #fade', function() {
        $('#fade , .popup_block').fadeOut(function() {
        });
	    return false;
    });
} 

    

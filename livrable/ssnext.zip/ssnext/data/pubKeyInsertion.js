/**
 * @author Maxence Pechoux, Florian Guilbert
 * 
 * Allows the insertion of the public key of the card in the user's profile
 */

function getTextValue() {
    return $('#edit_bio textarea.profileEditText').val();
}

/**
 * Set the key in the "About me" section
 */
function insert() {
    $('#edit_bio textarea.profileEditText').val(self.options.publicKey);
    $('#fbTimelineEditProfileDialog '
        + '.layerConfirm.uiOverlayButton.uiButton.uiButtonConfirm').click();
}

/**
 * A trick function to check every "time" seconds that the popup is loaded, 
 * before insterting the key.
 */
function delay(time, funToLaunch) {
    var testValue = getTextValue();
    if (typeof testValue === "undefined") {
        setTimeout(function(){delay(time, funToLaunch)}, time);
    } else {
        funToLaunch();
        return;
    }
}

/**
 * First make appear the popup "About me" for edition, then launch the delay 
 * function wait for the popup.
 */
function insertPubKey() {
    $('#bio_edit_button .uiButtonText').click();
    delay(1000, insert);
}

insertPubKey();



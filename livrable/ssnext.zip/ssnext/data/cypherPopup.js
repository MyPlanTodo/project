/**
 *  @author: Florian Guilbert, Maxence Péchoux
 */

/**
 * Create the checkbox to choose the lists for the encryption.
 */
function createCheckBoxes(lists) {
    let res = "";
    for (l in lists) {
        res += "<label><input id=\"check" + lists[l] + "\" type=\"checkbox\" />" 
            + lists[l] + "</label><br />";
    }
    return res;
}

/**
 * Check the lists which are checked and emit the event to trigger the encypt.
 */
function validPopup(listsA) {
    let res = [];
    let anonym;
    for (l in listsA) {
        if ($('#check' + listsA[l]).is(':checked')) {
            res.push(listsA[l]);
        }
    }
    if ($('#anonymous').is(':checked')) {
        anonym = true;
    } else {
        anonym = false;
    }
    var text = $("#u_0_k").next().val();
    var obj = { action : "encrypt" , ano : anonym, "list" : res, "data" : text};
    self.port.emit('encrypt', obj);
    $('#fade , .popup_block').fadeOut(function() {
    });
    return false;
}

/**
 * Add the button to let the user choose to encrypt his post.
 */
function addPostCypherButton() {
    var button = "<li><button class='_42ft _42fu _11b selected _42g- poplight' "
        + "data-width=\"300\" data-rel=\"popup1\" id=\'chiffrement\' "
        + "type=\'button\'>Chiffrer</button></li>";
    $('.uiList._1dso._427u.rfloat._4ki._6-h._6-j._6-i').append(button);
}

/**
 * If we are really in the page where there is the timeline.
 */
if ($('.storyContent').html() != null) {
    
    /* This function sets some parameters for the popup */
    jQuery(function($) {
            				   		   
    	$('.poplight').on('click', function() {
    		var popID = $(this).data('rel');
    		var popWidth = $(this).data('width');
    
        	$('#' + popID).fadeIn().css({ 'width': popWidth});
        
            $('#newList').focus();
    		var popMargTop = ($('#' + popID).height() + 80) / 2;
    		var popMargLeft = ($('#' + popID).width() + 80) / 2;
    		
            $('#' + popID).css({ 
                'margin': 'auto',
    			'margin-top' : '40px'
            });
    		
    		$('body').append('<div id="fade"></div>');
    		$('#fade').css(
                {'filter' : 'alpha(opacity=60)',
                'display' : 'none',
                'background' : '#000',
                'position' : 'fixed',
                'left' : '0',
                'top' : '0',
                'width' : '100%',
                'height' : '100%',
                'opacity': '.80',
                'z-index': '9999'}).fadeIn();
    
            return false;
    	});
        
        $('body').on('click', 'a.close, #fade', function() {
    		$('#fade , .popup_block').fadeOut(function() {
    	    });
    		return false;
    	});
        
    });
    
    addPostCypherButton();
}



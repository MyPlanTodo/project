/**
 * @author Maxence Pechoux, Zakaria Addi
 */

/**
 * Tags that will be prepended to our encrypted message
 */
var anonymBalise = "SSNEncryptedA";
var nonAnonymBalise = "SSNEncryptedN";

/**
 * Processing of message that are sent back encrypted by Facecrypt
 */
self.port.on('encrypted', function(data) {
    // According to the message type we prepend the appropriate tag and insert it 
    // to the hidden input for delivery
    if (data['ano']) {
        $("#u_0_k").next().val(anonymBalise + data['post']);
    } else {
        $("#u_0_k").next().val(nonAnonymBalise + data['post']);
    }
    // Once the hidden input is updated, we publish the post    
    $($('._42ft._42fu._11b.selected._42g-')[2]).click();
});
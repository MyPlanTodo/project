/**
 * @author Maxence Pechoux, Zakaria Addi
 * 
 * This content script will work on the friends list page. For users that have
 * lot of friends, we need to scroll down the page a certain number of times, so
 * that we can work on the whole list at once.
 */
 
// The variable that will be used to know in the end the total amount of friends
var friendsNb = "";

/**
 * This function will use a recursive tip to manage the absence of a function
 * wait. It will check if there's more friends to see, and if so, will scroll 
 * down to force the loading of the rest of the page. Only when the whole page 
 * is loaded, we call the function getFriends.
 */
function delay(time, funToLaunch) {
    var testValue = $('A.pam.uiBoxLightblue.uiMorePagerPrimary').html();
    if (testValue === "Afficher la suite") {
        window.scrollBy(0,10000);
        setTimeout(function(){delay(time, funToLaunch)}, time);
    } else {
        funToLaunch();
    }
}

/**
 * For each friend, we increment the number of friends, obtain his precise 
 * pseudo and then emit it to the add-on script. After the whole list has been 
 * treated, we emit it to the add-on with the total number of friends as a 
 * payload.
 */
function getFriends() {
    $('.fsl.fwb.fcb a').each(function() {
        friendsNb += "1";
        var pseudo = this.pathname;
        var exactPseudo = pseudo.substr(1, pseudo.length - 1);
        self.port.emit("friendPseudoReceived", exactPseudo);
    });
    self.port.emit("friendsListReceived", friendsNb);
}

// Delay is launched with a delay of 1 second.
delay(1000, getFriends);
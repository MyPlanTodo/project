/**
 *  @author: Florian Guilbert, Maxence Péchoux
 */


var allFriends = [];

/**
 * Remove a list in the database and in the GUI.
 */
function removeList(data) {
    var row = data.target.parentNode.parentNode;
    var list = row.firstChild.innerHTML;
    self.port.emit("suppressList", list);
    row.parentNode.removeChild(row);
    self.port.emit("getListsData");
    return false;
}


/**
 * Return the list of the friend's lists in html.
 */
function createUL(obj) {
    let res = "<table id=\"tableFriendsLists\" >";
    var k = 3;
    for (l in obj.lists) {
        res += "<tr><td>" + obj.lists[l] + "</td>";
        res += "<td><a data-width=\"300\" data-rel=\"popup" 
            + k 
            + "\" class=\"poplight2 uiHeaderAction\" href=\"#\" >Modifier</a>";
        res += "<div id=\"popup" 
            + k 
            + "\" class=\"_10 uiLayer popup_block\" role=\"dialog\" style=\"\">"
            + "<div class=\"_1yu\"><div class=\"_t\"><form action=# "
            + "class=\"_s\"><div id=\"u_a_0\" class=\"pvs phm _1yw\">" 
            + obj.lists[l] 
            + "</div><div style=\"padding:5px\" class=\"_13\">";
        for (f in obj.users) {
            if (obj.arrayList[l].indexOf(obj.users[f]) != -1) {
                res += "<label><input id=\"id" 
                    + obj.lists[l] + obj.users[f] 
                    + "\" type=\"checkbox\" checked />" 
                    + obj.users[f] 
                    + "</label><br />";
            } else {
                res += "<label><input id=\"id" 
                    + obj.lists[l] 
                    + obj.users[f] 
                    + "\" type=\"checkbox\" />" 
                    + obj.users[f] 
                    + "</label><br />";
            }
        }        
        res += "<br /><br /></div><div class=\"_14\" ><div class=\"pam "
            + "uiOverlayFooter uiBoxGray topborder\" ><table class=\"uiGrid\" "
            + "cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"prs "
            + "uiOverlayFooterMessage\"><td class=\"uiOverlayFooterButtons\">"
            + "<label class=\"modListButton layerConfirm uiOverlayButton "
            + "uiButton uiButtonConfirm uiButtonLarge\" for=\"modListButton\">"
            + "<input type=\"submit\" value=\"Synchroniser\"/></label><a "
            + "class=\"close layerCancel uiOverlayButton uiButton "
            + "uiButtonLarge\" role=\"button\" href=\"#\"><span "
            + "class=\"uiButtonText\">Cancel</span></a></td></tr></table></div>"
            + "</div></div></div></div>";
        res += "</td><td><a class=\"delFriendsLists uiHeaderActions\" "
            + "href=\"#\" >Supprimer</td></tr>";
        k += 1;
    }
    return res + "</table>";
}

/**
 * Plug the differents listeners in the friend's lists list.
 */
function plugPopupUL() {
    $('.delFriendsLists').click(function(data) { 
        removeList(data); return false;         
    });
    $('.modListButton').click(function(data) {
        synchronizeFriendsAndList(data) ; return false;         
    });
    $('.popup_block').css({
        'display': 'none',
        'float': 'left', 
        'z-index': '999999'
    });
    $('a.poplight2').on('click', function() {
        var popID = $(this).data('rel');
        var popWidth = $(this).data('width');

    	$('#' + popID).fadeIn().css({ 'width': popWidth});
    
		var popMargTop = ($('#' + popID).height() + 80) / 2;
		var popMargLeft = ($('#' + popID).width() + 80) / 2;
		
        $('#' + popID).css({ 
            'margin': 'auto',
			'margin-top' : '40px'
        });
		
		$('body').append('<div id="fade"></div>');
		$('#fade').css(
            {'filter' : 'alpha(opacity=60)',
            'display' : 'none',
            'background' : '#000',
            'position' : 'fixed',
            'left' : '0',
            'top' : '0',
            'width' : '100%',
            'height' : '100%',
            'opacity': '.80',
            'z-index': '9999'}).fadeIn();

        return false;
	});
}

/**
 * Add the friends who have been checked by the user in the database and
 * remove those who have been unchecked from the database.
 */
function synchronizeFriendsAndList(data) {
    let list = data.target.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.firstChild.innerHTML;
    var obj = {}; 
    obj.list = list;
    obj.arrayFriends = [];
    for (l in allFriends) {
        if (document.getElementById('id' + list + allFriends[l]).checked) {
            obj.arrayFriends.push(allFriends[l]);
        }
    }
    $('#fade , .popup_block').fadeOut(function() {
        /* $('#fade, a.close').remove();  */
    });
    self.port.emit("synList", obj);
    return false;
}

/**
 * Add a list in the database from the add popup.
 */
function addList() {
    var newList = $('#newList').val();
    $('#newList').val("");
    self.port.emit("createList", newList);
    $('#fade , .popup_block').fadeOut(function() {
    	/* $('#fade, a.close').remove();  */
    });
    self.port.emit("getListsData");
    return false;
}

/**
 * Create the add link and the corresponding popup.
 */
function createLinksPopup() {
    let div = "<div id=\"popup2\" class=\"_10 uiLayer popup_block\" "
        + "role=\"dialog\" style=\"\"><div class=\"_1yu\"><div class=\"_t\">"
        + "<form action=# class=\"_s\"><div id=\"u_a_0\" class=\"pvs phm _1yw\">"
        + "Nouvelle liste</div><div style=\"padding:5px\" class=\"_13\">"
        + "<h3>Liste d'amis :</h3> <input id=\"newList\" type=\"text\" "
        + "name=\"listname\" placeholder=\"Nom de la liste\" /><br /><br />"
        + "</div><div class=\"_14\" ><div class=\"pam uiOverlayFooter "
        + "uiBoxGray topborder\" ><table class=\"uiGrid\" cellspacing=\"0\" "
        + "cellpadding=\"0\"><tr><td class=\"prs uiOverlayFooterMessage\">"
        + "<td class=\"uiOverlayFooterButtons\"><label class=\"layerConfirm" 
        + "uiOverlayButton uiButton uiButtonConfirm uiButtonLarge\" "
        + "for=\"addListButton\"><input id=\"addListButton\" type=\"submit\" "
        + "value=\"Ajouter\"/></label><a class=\"close layerCancel "
        + "uiOverlayButton uiButton uiButtonLarge\" role=\"button\" href=\"#\">"
        + "<span class=\"uiButtonText\">Cancel</span></a></td></tr></table>"
        + "</div></div></div></div></div>";
    let res = "<a id=\"addList\" data-width=\"300\" data-rel=\"popup2\" "
        + "class=\"poplight uiHeaderAction\" href=\"#\" >Ajouter</a>";
    return res + " " + div;
}

/**
 * The following code trigger when the user is in the page where there
 * is the timeline.
 */
if ($('.storyContent').html() != null) {
    self.port.emit("getListsData");
    console.log("after emit");
    /**
     * When the database has been refreshed, some div and popup are refreshed too.
     */
    self.port.on("listsData", function(data) {
        allFriends = data.users;
        $('#tableFriendsLists').remove();
        $('#popup2').parent().append(createUL(data));
        plugPopupUL();
        $("#popup1").remove();
        var div = "<div id=\"popup1\" class=\"_10 uiLayer popup_block\" "
            + "role=\"dialog\" style=\"\"><div class=\"_1yu\"><div class=\"_t\">"
            + "<form action=# class=\"_s\"><div id=\"u_a_0\" class=\"pvs phm "
            + "_1yw\">Chiffrement</div><div style=\"padding:5px\" class=\"_13\">"
            + "<h3>Listes d'amis :</h3>" 
            + createCheckBoxes(data.lists) 
            + "<h3>Anonyme : </h3><input id=\"anonymous\" type=radio name=\"g1\" "
            + "checked /> oui<input id=\"nonAnonymous\" name=\"g1\" type=radio />"
            + " non<br /><br /></div><div class=\"_14\" ><div class=\"pam "
            + "uiOverlayFooter uiBoxGray topborder\" ><table class=\"uiGrid\" "
            + "cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"prs "
            + "uiOverlayFooterMessage\"><td class=\"uiOverlayFooterButtons\">"
            + "<label class=\"layerConfirm uiOverlayButton uiButton "
            + "uiButtonConfirm uiButtonLarge\" for=\"cypherButton\">"
            + "<input id=\"cypherButton\" type=\"submit\" value=\"Chiffrer\"/>"
            + "</label><a class=\"close layerCancel uiOverlayButton uiButton "
            + "uiButtonLarge\" role=\"button\" href=\"#\">"
            + "<span class=\"uiButtonText\">Cancel</span></a></td></tr></table>"
            + "</div></div></div></div></div>";
        $('.uiList._1dso._427u.rfloat._4ki._6-h._6-j._6-i').append(div);
        $('.popup_block').css({
            'display': 'none',
            'float': 'left', 
            'z-index': '999999'
        });
        $('#cypherButton').click({value : data.lists}, function(event) {
            validPopup(event.data.value);
            return false;
        });
        $('#addListButton').on('click', addList);
    });
    /**
     * Plug the "add link" in the page.
     */
    $('#pagelet_bookmark_nav').children().first()
        .append('<div id=friendsLists><h4 class="navHeader">Listes</h4>' 
        + createLinksPopup() 
        + '</div>');
    $('.popup_block').css({
            'display': 'none',
            'float': 'left', 
            'z-index': '999999'
    });
}



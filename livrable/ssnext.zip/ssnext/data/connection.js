/**
 * @author Maxence Pechoux
 * 
 * Intends to treat the login page : asking the card the ID, lauching a popup if
 * empty, complete login form...
 */

var pseudo;

/**
 * We receive the ID from the add-on script to be inserted in the form. We add
 * a click event on the connection button to fire a connected event to the addon
 */
self.port.on("ID", function(data) {
    pseudo = data['login'];
    $('#email').val(pseudo);
    $('#pass').val(data['pass']);
    $('#loginbutton:first-child').click(function() {
        self.port.emit("connected", pseudo);
    });
})

/**
 * Fire an event to ask the card for the user's ID
 */
function login() {
    self.port.emit("login");
}

/**
 * If the page is the login one, we put a listener on the reception of ID to
 * either launch the login popup or set the values and emit a "connected" event
 * to register the pseudo in the environment. 
 */
if ($('#loginbutton').html() != null) {
    self.port.on("loginReceived", function(data) {        
        if (data['firstConnection']) {
            // create popup asking for login and pass
            console.log("launchpop");
            launchPopup();            
        } else {
            pseudo = data['login'];
            $('#email').val(pseudo);
            $('#pass').val(data['pass']);
            $('#loginbutton:first-child').click(function() {
                self.port.emit("connected", pseudo);
            });
        }
    })
    login();
}
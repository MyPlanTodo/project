/**
 * @author Zakaria Addi
 * 
 * This script is used to modify the user's password thanks to the card
 */


/**
 * Wait for the form to be loaded, and then launch the modifFields function
 */
function delay(time, funToLaunch, data) {
    if ($("#password_new").html() == null) {
        setTimeout(function(){delay(time, funToLaunch, data)}, time);
    } else {
        funToLaunch(data);
    }
}

/**
 * Function that actually modifies the password fields. The click is let to the
 * user
 */
function modifFields(data) {
    
    // We retrieve both the generated password and the old password
    var old_password = data['oldPass'];
    var new_password = data['newPass'];
    // We modify the password modification form entry
    var totoi = $("#password_new").val();
    $("#password_new").val(new_password);
    $("#password_confirm").val(new_password);
    $("#password_old").val(old_password);
    // We activate the "save modification button"
    $(".submit.uiButtonDisabled.uiButton.uiButtonConfirm")
        .attr("class", "submit uiButton uiButtonConfirm")
        .attr("id", "myConfirm").removeAttr('disabled');
    $("#myConfirm").children().first().removeAttr('disabled');
    $("#myConfirm").click(function(event){
        self.port.emit("confirm",{action : "validPass"});
    });
}


/**
 * When we received the new and old passwords, we can start the procedure
 */
self.port.on('dataReceived',function(data){
    delay(1000, modifFields, data);
});

/**
 * When the page is loaded, we add a listener on the click of the modify password
 * link, that will emit a request for Facecrypt to change the password.
 */
$('.uiIconText.fbSettingsListItemEdit:eq(3)').click(function() {
    self.port.emit("modifPwd");
});